java -cp javax.json-1.0.4.jar:javax.json-api-1.0.jar:. BFClient $@
