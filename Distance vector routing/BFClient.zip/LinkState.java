
public enum LinkState {
	UP, DOWN
}
