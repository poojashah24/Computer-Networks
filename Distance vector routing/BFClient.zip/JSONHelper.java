import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonArrayBuilder;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;


public class JSONHelper {
	
	public static final String serialize(String command, List<DVEntry> distanceVectors, String myIP,
			int myPort)
	{
		String JSONString = null;
		if(distanceVectors != null)
		{
			
			JsonArrayBuilder arrayBuilder  = Json.createArrayBuilder();
			JsonObjectBuilder builder = Json.createObjectBuilder();
			arrayBuilder.add(builder.add(Constants.COMMAND, command));
			arrayBuilder.add(builder.add(Constants.SENDER_IP, myIP));
			arrayBuilder.add(builder.add(Constants.SENDER_PORT, myPort));
			for(DVEntry entry : distanceVectors)
			{
				double linkCost = entry.getCost();
				if(entry.getCost() == Double.POSITIVE_INFINITY)
					linkCost = -1;
				arrayBuilder.add(builder.add(Constants.IP, entry.getIpAddress())
																.add(Constants.PORT, entry.getPort())
																.add(Constants.WEIGHT, linkCost));

			}
			JSONString = arrayBuilder.build().toString();
		}
		return JSONString;
	}
	
	public static final String serialize(String command, String ipAddr, int port, String myIP,
																int myPort)
	{
		String JSONString = null;
		JsonArrayBuilder arrayBuilder  = Json.createArrayBuilder();
		JsonObjectBuilder builder = Json.createObjectBuilder();
		arrayBuilder.add(builder.add(Constants.COMMAND, command));
		arrayBuilder.add(builder.add(Constants.SENDER_IP, myIP));
		arrayBuilder.add(builder.add(Constants.SENDER_PORT, myPort));
		arrayBuilder.add(builder.add(Constants.IP, ipAddr));
		arrayBuilder.add(builder.add(Constants.PORT, port));
		
		JSONString = arrayBuilder.build().toString();
		return JSONString;
	}
	
	public static final List<Command> deserialize(String JSONString)
	{
		int i = 0;
		Command command = null;
		List<Command> commandList = new ArrayList<Command>();
		JsonReader reader = Json.createReader(new StringReader(JSONString));
		JsonArray array = reader.readArray();
		
		while(i < array.size())
		{
			JsonObject entry = array.getJsonObject(i++);
			String commandString = entry.getString(Constants.COMMAND);
			
			entry = array.getJsonObject(i++);
			String senderIP = entry.getString(Constants.SENDER_IP);
			
			entry = array.getJsonObject(i++);
			int senderPort = entry.getInt(Constants.SENDER_PORT);
			
			CommandEnum commandEnum = CommandEnum.valueOf(commandString);
			
			if(commandEnum.equals(CommandEnum.ROUTE_UPDATE))
			{
				List<DVEntry> distanceVector = new ArrayList<DVEntry>();
				for(;i<array.size(); i++)
				{
					entry = array.getJsonObject(i);
					int port = entry.getInt(Constants.PORT);
					double cost = entry.getInt(Constants.WEIGHT);
					if(cost == -1)
						cost = Double.POSITIVE_INFINITY;

					DVEntry dv = new DVEntry(entry.getString(Constants.IP), port, cost, null);
					distanceVector.add(dv);
				}
				
				command = new RouteUpdateCommand(distanceVector);
			} else if (commandEnum.equals(CommandEnum.LINKUP))
			{
				entry = array.getJsonObject(i++);
				String ipAddr = entry.getString(Constants.IP);
				
				entry = array.getJsonObject(i++);
				int port = entry.getInt(Constants.PORT);
				
				command = new LinkUpCommand(ipAddr, port, true);
			} else if (commandEnum.equals(CommandEnum.LINKDOWN))
			{
				entry = array.getJsonObject(i++);
				String ipAddr = entry.getString(Constants.IP);
				
				entry = array.getJsonObject(i++);
				int port = entry.getInt(Constants.PORT);
				
				command = new LinkDownCommand(ipAddr, port, true);
			}
			command.setSenderIP(senderIP);
			command.setSenderPort(senderPort);
			commandList.add(command);
		}
		
		
		return commandList;
	}
}
