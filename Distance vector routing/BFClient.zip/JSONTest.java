import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;


public class JSONTest {
	public static void main(String[] args) {
		List<DVEntry> entryList = new ArrayList<DVEntry>();
		DVEntry e1 = new DVEntry("127.0.0.1", 3000, 3, null);
		DVEntry e2 = new DVEntry("127.0.0.1", 6000, 6, null);
		DVEntry e3 = new DVEntry("127.0.0.1", 6000, 6, null);
		DVEntry e4 = new DVEntry("127.0.0.1", 6000, 6, null);
		DVEntry e5 = new DVEntry("127.0.0.1", 6000, 6, null);
		DVEntry e6 = new DVEntry("127.0.0.1", 3000, 3, null);
		DVEntry e7 = new DVEntry("127.0.0.1", 6000, 6, null);
		DVEntry e8 = new DVEntry("127.0.0.1", 6000, 6, null);
		DVEntry e9 = new DVEntry("127.0.0.1", 6000, 6, null);
		DVEntry e10 = new DVEntry("127.0.0.1", 6000, 6, null);
		
		entryList.add(e1);
		entryList.add(e2);
		entryList.add(e3);
		entryList.add(e4);
		entryList.add(e5);
		entryList.add(e6);
		entryList.add(e7);
		entryList.add(e8);
		entryList.add(e9);
		entryList.add(e10);
		
		String s = JSONHelper.serialize(CommandEnum.ROUTE_UPDATE.toString(), entryList,
				"127.0.0.1", 6000);
		System.out.println(s);
		byte[] buf = s.getBytes();
		System.out.println("bytes size: "+buf.length);
		
		List<Command> list = JSONHelper.deserialize(s);
		for(Command dv : list)
			System.out.println(((RouteUpdateCommand)dv).toString());
		
	}
}
